<?php
echo "if you get this page, there is something wrong !";
echo "Please make sure you have posted the survey";
?>